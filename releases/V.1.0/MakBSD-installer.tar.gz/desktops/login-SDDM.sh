_pih sddm "SDDM login manager"
sysrc sddm_enable="YES"
