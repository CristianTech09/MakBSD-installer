# ------------------------------------ pretty colors!

CR='\033[0;31m'		# color red
CG='\033[0;32m'		# color green
CC='\033[0;36m'		# color cyan
CY='\033[1;33m'		# color yellow
NC='\033[0m' 		# no color


# ------------------------------------ dialog

DIA_OPT_HEIGHT=15
DIA_OPT_WIDTH=60
DIA_CHOICE_HEIGHT=7
DIA_MSG_HEIGHT=7
DIA_MSG_WIDTH=60
DIA_RESULT=''	# results for menu, radiolist, checklist
DIA_BACKTITLE="Mak_BSD Installer for FreeBSD $VER"
DIA_OPTIONS="1 Option1
	2 Option2 "
